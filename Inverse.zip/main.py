def Inverse(n):
  return 1 / n
print(Inverse(int(input())))